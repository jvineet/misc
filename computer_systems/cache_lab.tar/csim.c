//Vineet Joshi (vineetj)


#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "contracts.h"


//declaring cache line as a struct
typedef struct{
  int valid;
  unsigned tag;
  int LRU_counter;
} cache_line;


//returns 2^x
int exp_two(int x){
  int res = 1;
  for(int i=1; i<=x; i++)
    res = res*2;
  return res;
}


//checks the cache memory and
//returns 1 for hit, 2 for miss, 3 for miss & evicton
int update_cache(cache_line *line, unsigned tag, int E){
  int max_ind = 0;
  int curr_max = line[0].LRU_counter;

  //checks hit
  for (int i=0; i<E; i++){
    if (line[i].tag == tag && line[i].valid == 1){
      line[i].LRU_counter = 0;     //reset counter
      return 1;                    //Hit
    }
  }

  //checks for empty line
  for (int i=0; i<E; i++){
    if (line[i].valid == 0){
      line[i].valid = 1;
      line[i].tag = tag;
      line[i].LRU_counter = 0;      //reset counter
      return 2;                     //Miss
    }

    //keeps track of maximum LRU seen so far
    if(curr_max < line[i].LRU_counter){
      max_ind = i;
      curr_max = line[i].LRU_counter;
    }
  }

  //replaces the contents of the least recently used block
  line[max_ind].tag = tag;
  line[max_ind].LRU_counter = 0;    //reset counter
  return 3;                         //Miss, Eviction
}


//increments LRU counter for all lines in the cache
void increment_timer(cache_line **cache, int S, int E){
  for (int i=0; i<S; i++){
    for (int j = 0; j<E; j++)
      cache[i][j].LRU_counter++;
  }
}


//prints verbose format for each line evaluation (use -v in command line)
void print_verbose(char identifier, unsigned address, int size, int msg){
  printf("%c %x %d", identifier, address, size);

  //prints action
  switch(msg) {
  case 1:
    printf("%s", " Hit");
    break;

  case 2:
    printf("%s", " Miss");
    break;

  case 3:
    printf("%s", " Miss Eviction");
    break;
  }

  if (identifier == 'M')
    printf("%s\n", " Hit");
  else
    printf("%s\n", " ");
}


//main function
int main(int argc, char** argv){
  int s,E,b,opt,S;
  int hits = 0;
  int misses = 0;
  int evictions = 0;

  char *tfile;
  int msg;
  FILE *trace;

  char identifier;
  unsigned address,tag,set_index;
  int size;
  int vflag = 0;

  //read input from readline
  while(-1 != (opt = getopt(argc, argv, "vs:E:b:t:"))){
    switch(opt) {
    case 'v':
      vflag = 1;
      break;

    case 's':
      s = atoi(optarg);
      break;

    case 'E':
      E = atoi(optarg);
      break;

    case 'b':
      b = atoi(optarg);
      break;

    case 't':
      tfile = optarg;
      break;

    default:
      abort ();
    }
  }

  S = exp_two(s);    //calculating number of sets

  //allot memory for cache in the heap
  cache_line **cache = (cache_line**) malloc(S*sizeof(cache_line*));
  for (int i = 0; i < S; ++i)
    cache[i] = (cache_line *) malloc(E * sizeof(cache_line));

  //open file for reading
  trace = fopen (tfile,"r");

  //read through tracefile line by line
  while(fscanf(trace," %c %x,%d", &identifier, &address, &size)>0){
    if (identifier == 'M' || identifier == 'L' || identifier == 'S'){
      tag = address >> (s+b);
      set_index = (address >> b) & ~(0xffffffffffffffff << s);

      //checks cache and update hits, misses and evictions
      //update_cache looks through the cache
      msg = update_cache(cache[set_index], tag, E);
      //switch counts hits, misses and evictions
      switch(msg) {
      case 1:
        hits++;
        break;

      case 2:
        misses++;
        break;

      case 3:
        misses++;
        evictions++;
        break;
      }

      if (identifier == 'M')
        hits++;

      if (vflag) //checks if verbose is to be printed
        print_verbose(identifier, address, size, msg);

      increment_timer(cache, S, E);
    }
  }
  fclose(trace);   //close file

  printSummary(hits, misses, evictions);
  return 0;
}
